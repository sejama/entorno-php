echo "accediendo al mysql-server"
docker exec -it mysql-server /bin/bash
