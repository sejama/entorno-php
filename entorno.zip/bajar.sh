echo 'Bajando entorno...'
docker compose -f docker-compose.yml down --remove-orphans
